package com.example.myapplication;

import java.util.Date;
import java.io.Serializable;


public class CartItem implements Serializable {
    private String serviceName;
    private String servicePlan;
    private Date date;

    // Constructors, getters, and other methods (if any) go here.

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public void setServicePlan(String servicePlan) {
        this.servicePlan = servicePlan;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getServicePlan() {
        return servicePlan;
    }

    public Date getDate() {
        return date;
    }
}
