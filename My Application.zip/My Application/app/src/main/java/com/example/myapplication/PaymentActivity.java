package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

public class PaymentActivity extends AppCompatActivity {
    RadioGroup paymentMethodGroup;
    RadioButton selectedPaymentMethod;
    Button paymentButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button on the toolbar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back); // Set your back icon here
        }

        paymentMethodGroup = findViewById(R.id.paymentMethodGroup);
        paymentButton = findViewById(R.id.paymentButton);

        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handlePayment();
            }
        });
    }

    private void handlePayment() {
        int selectedId = paymentMethodGroup.getCheckedRadioButtonId();
        selectedPaymentMethod = findViewById(selectedId);

        if (selectedPaymentMethod == null) {
            Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate payment details (card number, expiry date, CVC, etc.)
        boolean isValid = validatePaymentDetails();

        if (isValid) {
            // Display a success alert and provide an option to go back to the home page
            showSuccessAlert();
        } else {
            Toast.makeText(this, "Payment details are not valid", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validatePaymentDetails() {
        // Implement your validation logic here
        // Return true if payment details are valid, otherwise false
        return true; // Placeholder value
    }

    private void showSuccessAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Payment Successful")
                .setMessage("Your payment was successful!")
                .setPositiveButton("Go to Home", (dialog, which) -> {
                    // Start the HomeActivity and finish the PaymentActivity
                    Intent homeIntent = new Intent(PaymentActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
