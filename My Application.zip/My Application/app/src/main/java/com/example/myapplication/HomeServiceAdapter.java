package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeServiceAdapter extends RecyclerView.Adapter<HomeServiceAdapter.ViewHolder> {

    private List<String> allHomeServices;
    private List<String> filteredHomeServices;
    private OnItemClickListener listener;

    public HomeServiceAdapter(List<String> homeServices, OnItemClickListener listener) {
        this.allHomeServices = homeServices;
        this.filteredHomeServices = new ArrayList<>(homeServices);
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_home_service, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String serviceName = filteredHomeServices.get(position);
        holder.serviceNameTextView.setText(serviceName);

        // Set icon for each service based on your requirements
        // For example, you can load different icons based on the service name
        // holder.serviceIconImageView.setImageResource(R.drawable.ic_service_placeholder);

        // Set click listener for each item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onItemClick(serviceName);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return filteredHomeServices.size();
    }

    public void filterServices(String query) {
        filteredHomeServices.clear();
        if (query.isEmpty()) {
            filteredHomeServices.addAll(allHomeServices);
        } else {
            query = query.toLowerCase();
            for (String service : allHomeServices) {
                if (service.toLowerCase().contains(query)) {
                    filteredHomeServices.add(service);
                }
            }
        }
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView serviceNameTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            serviceNameTextView = itemView.findViewById(R.id.serviceNameTextView);
        }
    }

    // Interface to handle click events on the service items
    public interface OnItemClickListener {
        void onItemClick(String service);
    }
}
