package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
public class CartActivity extends AppCompatActivity {

    private RecyclerView recyclerViewCartItems;
    private CartAdapter cartAdapter;
    private List<CartItem> cartItems;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button on the toolbar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back); // Set your back icon here
        }

        // Get the cart items from the intent extra (assuming they were passed from ServiceDetailsActivity)
        cartItems = (List<CartItem>) getIntent().getSerializableExtra("cartItems");

        // Initialize the RecyclerView and the adapter for the cart items
        recyclerViewCartItems = findViewById(R.id.recyclerViewCartItems);
        recyclerViewCartItems.setLayoutManager(new LinearLayoutManager(this));
        cartAdapter = new CartAdapter(cartItems);
        recyclerViewCartItems.setAdapter(cartAdapter);

        Button proceedToPaymentButton = findViewById(R.id.proceedToPaymentButton);
        proceedToPaymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start PaymentActivity with cartItems as an intent extra
                Intent paymentIntent = new Intent(CartActivity.this, PaymentActivity.class);
                paymentIntent.putExtra("cartItems", new ArrayList<>(cartItems));
                startActivity(paymentIntent);}
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        // Load the cart items from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("cart", MODE_PRIVATE);
        String cartItemsJson = sharedPreferences.getString("cartItems", null);
        if (cartItemsJson != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<CartItem>>() {}.getType();
            cartItems = gson.fromJson(cartItemsJson, type);
        } else {
            cartItems = new ArrayList<>();
        }

        // Update the RecyclerView with the latest cart items
        if (cartAdapter != null) {
            cartAdapter.updateCartItems(cartItems);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
