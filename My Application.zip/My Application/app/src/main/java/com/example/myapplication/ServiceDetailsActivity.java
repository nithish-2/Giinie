package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ServiceDetailsActivity extends AppCompatActivity implements ServicePlansAdapter.OnPlanSelectedListener {

    private RecyclerView recyclerViewServicePlans;
    private ServicePlansAdapter servicePlansAdapter;

    private Button selectDateTimeButton;
    private Button addToCartButton;

    private String selectedPlan;
    private Date selectedDate;

    private List<CartItem> cartItems = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_details);

        // Initialize the RecyclerView and the adapter
        recyclerViewServicePlans = findViewById(R.id.recyclerViewServicePlans);
        recyclerViewServicePlans.setLayoutManager(new LinearLayoutManager(this));
        List<String> servicePlans = new ArrayList<>();
        servicePlans.add("Plan 1");
        servicePlans.add("Plan 2");
        servicePlans.add("Plan 3");
        // Add more service plans as needed
        servicePlansAdapter = new ServicePlansAdapter(servicePlans, this);
        recyclerViewServicePlans.setAdapter(servicePlansAdapter);

        // Initialize the "Select Date and Time" and "Add to Cart" buttons
        selectDateTimeButton = findViewById(R.id.selectDateTimeButton);
        addToCartButton = findViewById(R.id.addToCartButton);

        // Set click listener for "Select Date and Time" button to open the picker dialog
        selectDateTimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateTimePickerDialog();
            }
        });

        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedPlan != null && selectedDate != null) {
                    // Create a new CartItem object with the selected service details
                    CartItem cartItem = new CartItem();
                    cartItem.setServiceName("Your service name"); // Replace with the actual service name
                    cartItem.setServicePlan(selectedPlan);
                    cartItem.setDate(selectedDate);

                    // Add the CartItem to the cartItems list
                    cartItems.add(cartItem);

                    // Save the updated cart items to SharedPreferences
                    saveCartItemsToSharedPreferences();

                    // Display a toast message to indicate that the service has been added to the cart
                    Toast.makeText(ServiceDetailsActivity.this, "Service added to cart!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    // Display a toast message to indicate that the user should select a service plan and date/time first
                    Toast.makeText(ServiceDetailsActivity.this, "Please select a service plan and date/time", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void showDateTimePickerDialog() {
        // Get the current date and time
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        // Create a date picker dialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        // Set the selected date to the calendar instance
                        calendar.set(year, month, dayOfMonth);
                        // Create a time picker dialog
                        TimePickerDialog timePickerDialog = new TimePickerDialog(ServiceDetailsActivity.this,
                                new TimePickerDialog.OnTimeSetListener() {
                                    @Override
                                    public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                                        // Set the selected time to the calendar instance
                                        calendar.set(Calendar.HOUR_OF_DAY, hour);
                                        calendar.set(Calendar.MINUTE, minute);
                                        // Get the selected date as a Date object
                                        selectedDate = calendar.getTime();
                                        // Display the selected date and time on the button
                                        updateDateTimeButtonText();
                                    }
                                }, hour, minute, false);
                        timePickerDialog.show();
                    }
                }, year, month, dayOfMonth);
        datePickerDialog.show();
    }

    private void updateDateTimeButtonText() {
        if (selectedDate != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM d, yyyy - HH:mm", Locale.getDefault());
            selectDateTimeButton.setText(sdf.format(selectedDate));
        }
    }

    @Override
    public void onPlanSelected(String plan) {
        selectedPlan = plan;
    }



    private void saveCartItemsToSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("cart", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String cartItemsJson = gson.toJson(cartItems);
        editor.putString("cartItems", cartItemsJson);
        editor.apply();
    }

}
